
******************
NOTE ON OGG vs M4A
******************


.ogg files seamlessly loop.



.m4a files can NOT seamlessly loop.

This is a limitation of the file format.



Thank you for your purchase!

Joel Steudler
www.patreon.com/joelsteudler
joel@joelsteudlermusic.com